# EECSL Site Map

## Public Hub

- `/index.html`

## Teaching Pages

- `/teaching/cross-case-integration.html`
- `/teaching/capability-lab-links.html`

## Empirical Case Modules

- `/cases/higher-education-ips.html`
- `/cases/2008-financial-crisis.html`
- `/cases/geo-florida-prison.html`
- `/cases/florida-nursing-homes-visible-parasite.html`

## Shared Data

- `/data/cases.json`
- `/data/cross-case-integration.json`
- `/data/geo-florida-prison.json`
- `/data/florida-nursing-homes-visible-parasite.json`

## Shared Assets

- `/assets/`
- `/shared/`

## Layer Boundary

```text
Capability Lab
    public classroom simulation
        ↓
EECSL
    public empirical case-study analysis
        ↓
Navigator
    private student reflection and application
```
