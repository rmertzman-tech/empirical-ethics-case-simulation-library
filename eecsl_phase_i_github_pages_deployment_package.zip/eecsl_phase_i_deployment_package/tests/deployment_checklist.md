# EECSL Deployment Checklist

## Before upload

- [ ] `docs/index.html` exists.
- [ ] `docs/.nojekyll` exists.
- [ ] `docs/assets/` exists.
- [ ] `docs/shared/` exists.
- [ ] `docs/teaching/cross-case-integration.html` exists.
- [ ] `docs/teaching/capability-lab-links.html` exists.
- [ ] All four case pages exist in `docs/cases/`.

## GitHub Pages settings

- [ ] Repository is public or otherwise eligible for GitHub Pages under the account plan.
- [ ] Pages source is **Deploy from a branch**.
- [ ] Branch is `main`.
- [ ] Folder is `/docs`.
- [ ] Deployment has completed.

## Browser test

Open the deployed site and test:

- [ ] Library hub loads.
- [ ] Cross-case dashboard opens.
- [ ] Capability Lab links page opens.
- [ ] Higher Education IPS case opens.
- [ ] 2008 Financial Crisis case opens.
- [ ] GEO Florida case opens.
- [ ] Florida Nursing Homes case opens.
- [ ] Buttons and tabs respond.
- [ ] Styling appears.
- [ ] No obvious console errors.

## Classroom readiness

- [ ] Bookmark Library Hub.
- [ ] Bookmark Cross-Case Dashboard.
- [ ] Bookmark Capability Lab Public Studio.
- [ ] Decide which chapters will use each case.
- [ ] Keep private student reflection in Navigator or Canvas notebook, not in EECSL.
