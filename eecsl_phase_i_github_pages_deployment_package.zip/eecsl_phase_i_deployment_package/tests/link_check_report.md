# Static Link Check Report

HTML files checked: 15

No missing local `href` or `src` references were found by the static checker.


## Files checked

- Checked index.html
- Checked cases/shared-case-shell.html
- Checked cases/higher-education-ips.html
- Checked cases/florida-nursing-homes-visible-parasite.html
- Checked cases/2008-financial-crisis.html
- Checked cases/geo-florida-prison.html
- Checked methods/evidence-standards.html
- Checked methods/ips-methodology.html
- Checked methods/psage-methodology.html
- Checked methods/fhri-methodology.html
- Checked teaching/chapter-routing.html
- Checked teaching/instructor-notes.html
- Checked teaching/student-assignments.html
- Checked teaching/cross-case-integration.html
- Checked teaching/capability-lab-links.html
