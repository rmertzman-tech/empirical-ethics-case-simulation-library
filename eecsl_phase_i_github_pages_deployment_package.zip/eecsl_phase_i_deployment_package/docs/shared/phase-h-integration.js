
const INTEGRATION = {
  "title": "EECSL Phase H \u2014 Cross-Case Integration and Capability Lab Links",
  "capabilityLab": {
    "label": "Capability Lab Public Studio",
    "defaultUrl": "https://rmertzman-tech.github.io/capability-lab-public-studio/",
    "note": "Use this as the public classroom simulation studio. EECSL remains the empirical case-study library."
  },
  "cases": [
    {
      "id": "higher-ed-ips",
      "title": "Higher Education IPS",
      "short": "Higher Ed IPS",
      "url": "../cases/higher-education-ips.html",
      "hubUrl": "cases/higher-education-ips.html",
      "chapters": [
        "Chapter 11",
        "Chapter 5 extension",
        "Capstone"
      ],
      "labRoute": "Institutional design / public mission route",
      "bestUse": "Use when students need to see their own institution through public data, mission, access, cost, and structural incentives.",
      "simulation": "IPS teaching simulation with SPC / University of Phoenix parameter contrast.",
      "keyConcepts": [
        "IPS",
        "public mission",
        "exit option",
        "student debt",
        "FHRI_max",
        "mission alignment"
      ],
      "caseQuestion": "Where does a public college sit in the wider structural spectrum, and what does that reveal about mission, debt, access, and repair?"
    },
    {
      "id": "financial-crisis-2008",
      "title": "The 2008 Financial Crisis",
      "short": "2008 Financial Crisis",
      "url": "../cases/2008-financial-crisis.html",
      "hubUrl": "cases/2008-financial-crisis.html",
      "chapters": [
        "Chapter 3",
        "Chapter 12",
        "Capstone"
      ],
      "labRoute": "Evidence policy / systemic warning route",
      "bestUse": "Use when students need to understand signal failure, rating normalization, systemic risk, and T1 vs T2 recovery.",
      "simulation": "Timeline and live coherence-map simulation with T1/T2 repair controls.",
      "keyConcepts": [
        "P-SAGE",
        "Triadic Overwrite",
        "evidence policy",
        "T1/T2",
        "systemic risk",
        "rating normalization"
      ],
      "caseQuestion": "How can a financial system preserve operational continuity while replacing the ethical function of its warning and signal channels?"
    },
    {
      "id": "geo-florida",
      "title": "GEO Group Florida",
      "short": "GEO Florida",
      "url": "../cases/geo-florida-prison.html",
      "hubUrl": "cases/geo-florida-prison.html",
      "chapters": [
        "Chapter 5",
        "Chapter 7",
        "Chapter 10",
        "Capstone"
      ],
      "labRoute": "Justice / moral commons / captive-population route",
      "bestUse": "Use when students need to examine the gap between formal legality, public safety claims, captive populations, and actual capability.",
      "simulation": "Repair simulator with BioBond, Public Benefit Corporation governance, and Maathai pathway controls.",
      "keyConcepts": [
        "justice",
        "capabilities",
        "moral commons",
        "BioBond",
        "Maathai pathway",
        "captive population"
      ],
      "caseQuestion": "What would it take to move a captive-population institution from extraction architecture toward moral-commons repair?"
    },
    {
      "id": "florida-nursing-homes",
      "title": "Florida Nursing Homes and the Visible Parasite",
      "short": "Nursing Homes",
      "url": "../cases/florida-nursing-homes-visible-parasite.html",
      "hubUrl": "cases/florida-nursing-homes-visible-parasite.html",
      "chapters": [
        "Chapter 12",
        "Chapter 13",
        "Chapter 15",
        "Capstone"
      ],
      "labRoute": "Care / public vulnerability / T1-T2 repair route",
      "bestUse": "Use when students need to see how a care institution can measure quality while still absorbing care capacity through ownership and staffing structure.",
      "simulation": "Visible Parasite repair simulator, SAGE scenario, and T1/T2 intervention classifier.",
      "keyConcepts": [
        "care ethics",
        "Visible Parasite",
        "FHRI_max",
        "T1/T2",
        "HHVBP",
        "ownership opacity",
        "SAGE"
      ],
      "caseQuestion": "How can a care institution formally organized around resident protection shift risk, cost, and vulnerability onto residents, workers, families, and public systems?"
    }
  ],
  "chapterRoutes": [
    {
      "chapter": "Chapter 1",
      "title": "Ethical Perception, Complexity, and the Need for Models",
      "capabilityLab": "Use the Schelling emergence simulation as the first demonstration of why ethical outcomes can exceed individual intentions.",
      "eecsl": "Preview the EECSL only lightly: explain that later chapters will use empirical simulations to examine real institutions.",
      "cases": [
        "Higher Education IPS preview"
      ],
      "classMove": "Do not overload students with IPS yet. Use the contrast between simple local rules and emergent social patterns."
    },
    {
      "chapter": "Chapter 3",
      "title": "Evidence Policy, Warning, and Ethical Lenses",
      "capabilityLab": "Use the Challenger / Boisjoly classroom run mode.",
      "eecsl": "Open the 2008 Financial Crisis case for a second, larger-scale example of evidence-channel failure.",
      "cases": [
        "The 2008 Financial Crisis"
      ],
      "classMove": "Compare engineering warning suppression with financial rating normalization."
    },
    {
      "chapter": "Chapter 4",
      "title": "Systems, Emergence, and Responsibility",
      "capabilityLab": "Use Schelling and coordination-under-heat to show layered emergence.",
      "eecsl": "Use Higher Education IPS or 2008 Financial Crisis to show how modeled parameters become empirical structural questions.",
      "cases": [
        "Higher Education IPS",
        "The 2008 Financial Crisis"
      ],
      "classMove": "Ask how responsibility changes when harms arise from architecture rather than isolated intention."
    },
    {
      "chapter": "Chapter 5",
      "title": "Social Contract, Justice, and the Moral Commons",
      "capabilityLab": "Use the civic coordination route with Repair preset.",
      "eecsl": "Use GEO Florida as the primary empirical justice case and Higher Education IPS as a rights-to-capabilities extension.",
      "cases": [
        "GEO Group Florida",
        "Higher Education IPS"
      ],
      "classMove": "Connect Rawls, Nussbaum, functional equivalence, John Hope Franklin, and Maathai-style shared task coordination."
    },
    {
      "chapter": "Chapter 11",
      "title": "Education, Economics, and Institutional Design",
      "capabilityLab": "Use a short institutional-design warm-up.",
      "eecsl": "Use Higher Education IPS as the primary empirical case.",
      "cases": [
        "Higher Education IPS"
      ],
      "classMove": "Let students examine a public institution close enough to matter without requiring private disclosure."
    },
    {
      "chapter": "Chapter 12",
      "title": "Systems, Governance, Care, and Institutional Risk",
      "capabilityLab": "Use coordination-under-heat and evidence-policy framing.",
      "eecsl": "Use 2008 Financial Crisis and Florida Nursing Homes as paired cases.",
      "cases": [
        "The 2008 Financial Crisis",
        "Florida Nursing Homes and the Visible Parasite"
      ],
      "classMove": "Compare operational recovery, measurement programs, and structural repair."
    },
    {
      "chapter": "Capstone",
      "title": "Comparative Structural Ethics",
      "capabilityLab": "Use the active analysis toolbelt: Lens Audit, Hidden Costs, Repair Builder, Navigator Bridge, Instructor Toolkit.",
      "eecsl": "Use all four empirical case modules in comparison.",
      "cases": [
        "Higher Education IPS",
        "The 2008 Financial Crisis",
        "GEO Group Florida",
        "Florida Nursing Homes and the Visible Parasite"
      ],
      "classMove": "Ask students to distinguish data, model output, interpretation, and repair proposal across domains."
    }
  ],
  "conceptThreads": [
    {
      "concept": "Structural Ceiling / FHRI_max",
      "question": "When does agent capacity get absorbed by institutional structure?",
      "cases": [
        "Higher Education IPS",
        "GEO Florida",
        "Nursing Homes",
        "2008 Financial Crisis"
      ],
      "labLink": "Use Capability Lab results to ask whether a simulation produced success, repair, or merely temporary coordination."
    },
    {
      "concept": "P-SAGE / Triadic Overwrite",
      "question": "When do signs remain operational while their ethical meaning is replaced?",
      "cases": [
        "2008 Financial Crisis",
        "GEO Florida",
        "Nursing Homes"
      ],
      "labLink": "Use Challenger as the introductory warning-suppression example, then scale up to empirical cases."
    },
    {
      "concept": "T1 vs T2 Repair",
      "question": "Does the intervention change the access condition or merely improve behavior inside the same ceiling?",
      "cases": [
        "2008 Financial Crisis",
        "GEO Florida",
        "Nursing Homes"
      ],
      "labLink": "Use the active toolbelt Repair Builder after students run a simulation."
    },
    {
      "concept": "Functional Equivalence / Moral Commons",
      "question": "Can different PRFs support the same shared task for different authentic reasons?",
      "cases": [
        "GEO Florida",
        "Higher Education IPS",
        "Nursing Homes"
      ],
      "labLink": "Use Chapter 5 civic coordination with Repair preset before opening the empirical case."
    },
    {
      "concept": "Evidence Governance",
      "question": "Which claims are data, computed outputs, interpretations, teaching prompts, or hypotheses?",
      "cases": [
        "All EECSL cases"
      ],
      "labLink": "Use Capability Lab as public classroom simulation; use EECSL for evidence-governed empirical case modules."
    }
  ],
  "toolbelt": [
    {
      "button": "Open Simulation",
      "purpose": "Run the public classroom demonstration first.",
      "output": "Initial pattern, failure, or repair signature."
    },
    {
      "button": "Ethical Lens Audit",
      "purpose": "Ask what the system forms, respects, produces, distributes, exploits, and hears.",
      "output": "Lens-specific ethical questions."
    },
    {
      "button": "Hidden Costs",
      "purpose": "Identify who bears \u03c6 load, credibility burden, care burden, risk, delay, or loss.",
      "output": "Hidden-cost inventory."
    },
    {
      "button": "Repair Builder",
      "purpose": "Separate T1 structural repairs from T2 agent/process improvements.",
      "output": "Repair proposal with claim type."
    },
    {
      "button": "Open EECSL Case",
      "purpose": "Move from classroom simulation to empirical case study.",
      "output": "Evidence-governed case module."
    },
    {
      "button": "Navigator Bridge",
      "purpose": "Move from public case to private student application without exposing private data.",
      "output": "Private reflection route."
    }
  ]
};

function esc(x) {
  return String(x ?? "").replace(/[&<>\"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#039;'}[m]));
}

function caseCard(c, rootPrefix="../") {
  return `<article class="case-card">
    <div class="small-label">${esc(c.labRoute)}</div>
    <h3>${esc(c.title)}</h3>
    <p><strong>Best use:</strong> ${esc(c.bestUse)}</p>
    <p><strong>Simulation:</strong> ${esc(c.simulation)}</p>
    <div class="pill-row">${c.chapters.map(ch=>`<span class="pill">${esc(ch)}</span>`).join("")}</div>
    <div class="spacer"></div>
    <div class="actions">
      <a class="button primary" href="${rootPrefix}${esc(c.hubUrl)}">Open EECSL case</a>
      <button class="button" data-case="${esc(c.id)}">Build class move</button>
    </div>
  </article>`;
}

function renderCases(rootPrefix="../") {
  const el = document.getElementById("caseGrid");
  if (!el) return;
  el.innerHTML = INTEGRATION.cases.map(c => caseCard(c, rootPrefix)).join("");
  document.querySelectorAll("[data-case]").forEach(btn => btn.addEventListener("click", () => buildClassMove(btn.dataset.case)));
}

function renderRoutes() {
  const el = document.getElementById("routeGrid");
  if (!el) return;
  el.innerHTML = INTEGRATION.chapterRoutes.map(r => `<article class="route-card">
    <strong>${esc(r.chapter)} — ${esc(r.title)}</strong>
    <p><b>Capability Lab:</b> ${esc(r.capabilityLab)}</p>
    <p><b>EECSL:</b> ${esc(r.eecsl)}</p>
    <div class="pill-row">${r.cases.map(c=>`<span class="pill gold">${esc(c)}</span>`).join("")}</div>
    <p class="footer-note">${esc(r.classMove)}</p>
  </article>`).join("");
}

function renderConcepts() {
  const el = document.getElementById("conceptGrid");
  if (!el) return;
  el.innerHTML = INTEGRATION.conceptThreads.map(c => `<article class="concept-card">
    <strong>${esc(c.concept)}</strong>
    <p>${esc(c.question)}</p>
    <div class="pill-row">${c.cases.map(x=>`<span class="pill">${esc(x)}</span>`).join("")}</div>
    <p class="footer-note">${esc(c.labLink)}</p>
  </article>`).join("");
}

function renderToolbelt() {
  const el = document.getElementById("toolGrid");
  if (!el) return;
  el.innerHTML = INTEGRATION.toolbelt.map(t => `<article class="tool-card">
    <strong>${esc(t.button)}</strong>
    <p>${esc(t.purpose)}</p>
    <p class="footer-note"><b>Output:</b> ${esc(t.output)}</p>
  </article>`).join("");
}

function renderMatrix() {
  const el = document.getElementById("matrixBody");
  if (!el) return;
  el.innerHTML = INTEGRATION.cases.map(c => `<tr>
    <td><strong>${esc(c.short)}</strong></td>
    <td>${esc(c.chapters.join(", "))}</td>
    <td>${esc(c.caseQuestion)}</td>
    <td>${esc(c.keyConcepts.join(", "))}</td>
    <td>${esc(c.simulation)}</td>
    <td><a class="button" href="../${esc(c.hubUrl)}">Open</a></td>
  </tr>`).join("");
}

function buildClassMove(id) {
  const c = INTEGRATION.cases.find(x => x.id === id) || INTEGRATION.cases[0];
  const text = [
    "Classroom move: " + c.title,
    "",
    "1. Start in the Capability Lab.",
    "   Route: " + c.labRoute,
    "",
    "2. Ask students the public case question.",
    "   " + c.caseQuestion,
    "",
    "3. Run the EECSL case module.",
    "   Simulation: " + c.simulation,
    "",
    "4. Use the toolbelt.",
    "   Lens Audit → Hidden Costs → Repair Builder → Navigator Bridge",
    "",
    "5. Keep the evidence rule visible.",
    "   Separate public data, computed model output, interpretive claim, teaching prompt, and research hypothesis.",
    "",
    "6. Private reflection boundary.",
    "   Students may connect the case to their own lives only in the Navigator or private course notebook."
  ].join("\n");
  const el = document.getElementById("classMoveOutput");
  if (el) {
    el.textContent = text;
    el.scrollIntoView({behavior:"smooth", block:"center"});
  }
}

function chapterSelect() {
  const selected = document.getElementById("chapterSelect")?.value;
  const r = INTEGRATION.chapterRoutes.find(x => x.chapter === selected) || INTEGRATION.chapterRoutes[0];
  const el = document.getElementById("chapterOutput");
  if (!el) return;
  el.innerHTML = `<div class="workspace">
    <h3>${esc(r.chapter)} — ${esc(r.title)}</h3>
    <div class="connection">
      <div class="card"><div class="small-label">Capability Lab</div><p>${esc(r.capabilityLab)}</p></div>
      <div class="arrow">→</div>
      <div class="card"><div class="small-label">EECSL</div><p>${esc(r.eecsl)}</p></div>
    </div>
    <div class="pill-row">${r.cases.map(c=>`<span class="pill gold">${esc(c)}</span>`).join("")}</div>
    <div class="notice"><strong>Class move:</strong><p>${esc(r.classMove)}</p></div>
  </div>`;
}

function generateCapabilityLabLinks() {
  const base = (document.getElementById("eecslBase")?.value || "").replace(/\/$/, "");
  const out = INTEGRATION.cases.map(c => {
    const url = base ? base + "/" + c.hubUrl : c.hubUrl;
    return `    <a class="button primary" href="${esc(url)}">${esc(c.short)}</a>`;
  }).join("\n");
  const code = `<section class="eecsl-link-panel">
  <h2>Open EECSL Empirical Case</h2>
  <p>Move from the classroom simulation to an evidence-governed empirical case module.</p>
  <div class="actions">
${out}
  </div>
</section>`;
  const el = document.getElementById("linkCode");
  if (el) el.textContent = code;
}

document.addEventListener("DOMContentLoaded", () => {
  const rootPrefix = document.body.dataset.rootPrefix || "../";
  renderCases(rootPrefix);
  renderRoutes();
  renderConcepts();
  renderToolbelt();
  renderMatrix();
  const sel = document.getElementById("chapterSelect");
  if (sel) {
    sel.innerHTML = INTEGRATION.chapterRoutes.map(r=>`<option value="${esc(r.chapter)}">${esc(r.chapter)} — ${esc(r.title)}</option>`).join("");
    sel.addEventListener("change", chapterSelect);
    chapterSelect();
  }
  const linkBtn = document.getElementById("generateLinksBtn");
  if (linkBtn) linkBtn.addEventListener("click", generateCapabilityLabLinks);
  generateCapabilityLabLinks();
});
