# Local Preview

A GitHub Pages site made from static HTML can be previewed locally.

From the repository root:

```bash
cd docs
python3 -m http.server 8000
```

Then open:

`http://localhost:8000/`

This local preview is optional. The site is designed to work directly on GitHub Pages.
