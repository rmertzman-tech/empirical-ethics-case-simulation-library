# Empirical Ethics Case Simulation Library — EECSL

**Phase I deployment package**

This repository package is ready for GitHub Pages deployment using the `docs/` folder as the publishing source.

## Layer rule

- **Capability Lab** = public classroom simulation studio
- **EECSL** = public empirical ethics case-study library
- **Navigator** = private student application and reflection layer

## Recommended repository name

`empirical-ethics-case-simulation-library`

That would give the public site this likely URL pattern:

`https://rmertzman-tech.github.io/empirical-ethics-case-simulation-library/`

## Recommended GitHub Pages setting

Use:

- Branch: `main`
- Folder: `/docs`

The site entry file is:

`docs/index.html`

## Main pages

- `docs/index.html` — Library hub
- `docs/teaching/cross-case-integration.html` — Phase H cross-case teaching dashboard
- `docs/teaching/capability-lab-links.html` — Capability Lab → EECSL bridge page
- `docs/cases/higher-education-ips.html`
- `docs/cases/2008-financial-crisis.html`
- `docs/cases/geo-florida-prison.html`
- `docs/cases/florida-nursing-homes-visible-parasite.html`

## Deployment summary

1. Create or open the GitHub repository.
2. Upload everything in this package to the repository root.
3. Confirm that `docs/index.html` exists.
4. Go to **Settings → Pages**.
5. Set **Source** to **Deploy from a branch**.
6. Set **Branch** to `main` and folder to `/docs`.
7. Save.
8. Wait for GitHub Pages to publish the site.

## After deployment

Open:

`https://rmertzman-tech.github.io/empirical-ethics-case-simulation-library/`

Then test the case pages, teaching dashboard, and Capability Lab bridge links.
